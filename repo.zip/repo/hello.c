#include<stdio.h>
void main()
{
printf("\nHello World!\n");
printf("\nHello Vignan!\n");
}
